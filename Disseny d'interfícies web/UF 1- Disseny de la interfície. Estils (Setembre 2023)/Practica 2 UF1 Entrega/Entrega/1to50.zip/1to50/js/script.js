// Logica del juego
document.addEventListener("DOMContentLoaded", function () {
    const tablero = document.getElementById("tablero");
    const numeroActualContainer = document.getElementById("numero-actual");

    let numeroEsperado = 1;
    let numerosRestantes = Array.from({ length: 25 }, (_, index) => index + 26);

    iniciarPartida();
    
    // Funcion que prepara el tablero para iniciar la partida
    function iniciarPartida() {
        let numerosIniciales = Array.from({ length: 25 }, (_, index) => index + 1);

        // Mezclamos los numeros iniciales y los restantes
        mezclarArray(numerosIniciales);
        mezclarArray(numerosRestantes);

        // Agregamos los numeros iniciales al tablero
        for (let i = 0; i < 5; i++) {
            for (let j = 0; j < 5; j++) {
                const casilla = document.createElement("div");
                casilla.className = "casilla";
                casilla.textContent = numerosIniciales.shift();
                casilla.addEventListener("click", () => pulsarCasilla(casilla));
                tablero.appendChild(casilla);
            }
        }

        resaltarCasilla(numeroEsperado);
        updateNumeroActual();
    }

    // Funcion que se ejecuta cuando se hace click en una casilla
    function pulsarCasilla(casilla) {
        const numeroSeleccionado = parseInt(casilla.textContent);

        if (numeroSeleccionado === numeroEsperado) {
            if (numeroEsperado === 1) {
                iniciarTemporizador();
            }

            numeroEsperado++;

            if (numeroEsperado < 51) {
                const nuevoNumero = numerosRestantes.shift();
                casilla.textContent = nuevoNumero;

                resaltarCasilla(numeroEsperado);
                updateNumeroActual();
            } else {
                detenerTemporizador();
                casilla.textContent = undefined;
                resaltarCasilla(numeroEsperado);
            }
        }
    }

    // Funcion que actualiza el numero actual
    function updateNumeroActual() {
        numeroActualContainer.textContent = "Número actual: " + numeroEsperado;
    }

    // Funcion que utiliza el metodo fisher yates para mezclar los numeros
    function mezclarArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
    }

    // Funcion que resalta la casilla que contiene el numero esperado
    function resaltarCasilla(numero) {
        const casillas = document.getElementsByClassName("casilla");
    
        for (const casilla of casillas) {
            casilla.classList.remove("resaltada");
            if (casilla.textContent === numero.toString()) {
                casilla.classList.add("resaltada");
            }
        }
    }
});


// Temporizador
let tiempoInicio;
let tiempoSpan = document.getElementById("tiempo");
let temporizadorInterval;

function iniciarTemporizador() {
    tiempoInicio = new Date().getTime();
    temporizadorInterval = setInterval(() => {
        const tiempoTranscurrido = new Date().getTime() - tiempoInicio;
        const segundos = Math.floor(tiempoTranscurrido / 1000);
        const milisegundos = tiempoTranscurrido % 1000;
        tiempoSpan.textContent = `${segundos}.${milisegundos.toString().padStart(3, '0')}`;
    }, 100);
}

function detenerTemporizador() {
    clearInterval(temporizadorInterval);
}