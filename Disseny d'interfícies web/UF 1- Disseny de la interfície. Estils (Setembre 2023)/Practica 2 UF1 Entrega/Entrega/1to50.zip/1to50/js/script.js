let isDarkMode = false;
let tiempoInicio;
let tiempoTranscurrido = 0;
let tiempoSpan = document.getElementById("tiempo");
let temporizadorInterval;

function toggleTheme() {
    const body = document.body;
    const toggleButton = document.getElementById("toggleButton");

    if (isDarkMode) {
        body.style.backgroundColor = "#f0f0f0";
        body.style.color = "#000";
        toggleButton.style.color = "#000";
        toggleButton.style.backgroundColor = "#f0f0f0";
        toggleButton.style.borderColor = "#000";
    } else {
        body.style.backgroundColor = "#0f0f0f";
        body.style.color = "#fff";
        toggleButton.style.color = "#fff";
        toggleButton.style.backgroundColor = "#0f0f0f";
        toggleButton.style.borderColor = "#fff";
    }

    isDarkMode = !isDarkMode;
}

function iniciarTemporizador() {
    tiempoInicio = new Date().getTime();
    temporizadorInterval = setInterval(actualizarTemporizador, 100);
}

function detenerTemporizador() {
    clearInterval(temporizadorInterval);
}

function actualizarTemporizador() {
    const ahora = new Date().getTime();
    tiempoTranscurrido = ahora - tiempoInicio;
    const segundos = Math.floor(tiempoTranscurrido / 1000);
    const milisegundos = tiempoTranscurrido % 1000;

    tiempoSpan.textContent = `${segundos}.${milisegundos.toString().padStart(3, '0')}`;
}

document.addEventListener("DOMContentLoaded", function () {
    const tablero = document.getElementById("tablero");
    const numerosRestantesContainer = document.getElementById("numeros-restantes");
    const numeroActualContainer = document.getElementById("numero-actual");

    let numerosRestantes = Array.from({ length: 49 }, (_, index) => index + 2);
    shuffleArray(numerosRestantes);

    let numeroEsperado = 1;

    const indiceAleatorio = Math.floor(Math.random() * 25);

    for (let i = 0; i < 5; i++) {
        for (let j = 0; j < 5; j++) {
            const casilla = document.createElement("div");
            casilla.className = "casilla";
            if (i * 5 + j === indiceAleatorio) {
                casilla.textContent = 1;
            } else {
                casilla.textContent = numerosRestantes.pop();
            }
            casilla.addEventListener("click", () => handleClick(casilla));
            tablero.appendChild(casilla);
        }
    }

    resaltarCasilla(numeroEsperado);

    updateNumerosRestantes();
    updateNumeroActual();

    function resaltarCasilla(numero) {
        const casillas = document.getElementsByClassName("casilla");

        for (const casilla of casillas) {
            casilla.classList.remove("resaltada");
        }

        for (const casilla of casillas) {
            if (casilla.textContent === numero.toString()) {
                casilla.classList.add("resaltada");
            }
        }
    }

    function handleClick(casilla) {
        const numeroSeleccionado = parseInt(casilla.textContent);

        if (numeroSeleccionado === numeroEsperado) {
            if (numeroEsperado === 1) {
                iniciarTemporizador();
            }

            numeroEsperado++;

            if (numeroEsperado < 51) {
                const indiceNumeroEsperado = numerosRestantes.indexOf(numeroEsperado);

                if (indiceNumeroEsperado !== -1) {
                    casilla.textContent = numeroEsperado;
                    numerosRestantes.splice(indiceNumeroEsperado, 1);
                } else {
                    const nuevoNumero = numerosRestantes.pop();
                    casilla.textContent = nuevoNumero;
                }

                resaltarCasilla(numeroEsperado);
                updateNumerosRestantes();
                updateNumeroActual();
                console.log(`Número seleccionado: ${numeroSeleccionado}`);
            } else {
                detenerTemporizador();
                const nuevoNumero = numerosRestantes.pop();
                casilla.textContent = nuevoNumero;
                resaltarCasilla(numeroEsperado);
                console.log("¡Juego completado!");
            }
        } else {
            console.log("¡Selecciona los números en orden!");
        }
    }

    function updateNumerosRestantes() {
        numerosRestantesContainer.textContent = "Números restantes: " + numerosRestantes.join(", ");
    }

    function updateNumeroActual() {
        numeroActualContainer.textContent = "Número actual: " + numeroEsperado;
    }

    function shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
    }
});