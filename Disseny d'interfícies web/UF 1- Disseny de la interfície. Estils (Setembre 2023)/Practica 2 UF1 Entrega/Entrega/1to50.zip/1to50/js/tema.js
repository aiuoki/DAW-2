// Cambiar el tema de la página
let isDarkMode = false;

function toggleTheme() {
    const body = document.body;
    const toggleButton = document.getElementById("toggleButton");

    if (isDarkMode) {
        body.style.backgroundColor = "#f0f0f0";
        body.style.color = "#000";
        toggleButton.style.color = "#000";
        toggleButton.style.backgroundColor = "#f0f0f0";
        toggleButton.style.borderColor = "#000";
    } else {
        body.style.backgroundColor = "#0f0f0f";
        body.style.color = "#fff";
        toggleButton.style.color = "#fff";
        toggleButton.style.backgroundColor = "#0f0f0f";
        toggleButton.style.borderColor = "#fff";
    }

    isDarkMode = !isDarkMode;
}