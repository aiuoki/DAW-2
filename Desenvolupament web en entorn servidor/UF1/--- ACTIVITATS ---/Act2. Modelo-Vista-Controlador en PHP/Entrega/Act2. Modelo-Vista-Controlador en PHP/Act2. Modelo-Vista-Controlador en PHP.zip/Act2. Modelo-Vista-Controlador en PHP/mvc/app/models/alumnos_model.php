<?php
// Incluir el archivo alumnos_controller.php
require_once '../controllers/alumnos_controller.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Obtener los datos enviados por el formulario
    $nombre = $_POST['nombre'];
    $apellidos = $_POST['apellidos'];
    $dni = $_POST['dni'];
    $curso = $_POST['curso'];

    // Crear un nuevo alumno utilizando la función crearAlumno del modelo
    AlumnosController::crearAlumno($nombre, $apellidos, $dni, $curso);
    
    // Redirigir al usuario a otra página
    header('Location: ../views/mostrar_alumnos_view.php');
    exit;
} else {
    // Obtener todos los alumnos utilizando la función mostrarAlumnos del modelo
    $alumnos = AlumnosController::mostrarAlumnos();
}
?>
