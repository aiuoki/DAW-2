<?php
require_once '../db/db.php';

class AnimalesModel {
    public static function crearAnimal($especie, $nombre, $fecha_nacimiento, $peso) {
        $conexion = Conectar::conexion();
        $stmt = $conexion->prepare("INSERT INTO animales (especie, nombre, fecha_nacimiento, peso) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("sssi", $especie, $nombre, $fecha_nacimiento, $peso);
        $stmt->execute();
        $stmt->close();
        $conexion->close();
    }
    public static function mostrarAnimales() {
        $conexion = Conectar::conexion();
        $stmt = $conexion->prepare("SELECT * FROM animales");
        $stmt->execute();
        $resultados = $stmt->get_result();
        $animales = array();
        while ($fila = $resultados->fetch_assoc()) {
            $animales[] = $fila;
        }
        $stmt->close();
        $conexion->close();
        return $animales;
    }
    public static function modificarAnimal($id_animal, $especie, $nombre, $fecha_nacimiento, $peso) {
        $conexion = Conectar::conexion();
        $stmt = $conexion->prepare("UPDATE animales SET especie=?, nombre=?, fecha_nacimiento=?, peso=? WHERE id_animal=?");
        $stmt->bind_param("sssii", $especie, $nombre, $fecha_nacimiento, $peso, $id_animal);
        $stmt->execute();
        $stmt->close();
        $conexion->close();
    }
    public static function eliminarAnimal($id_animal) {
        $conexion = Conectar::conexion();
        $stmt = $conexion->prepare("DELETE FROM animales WHERE id_animal = ?");
        $stmt->bind_param("i", $id_animal);
        $stmt->execute();
        $stmt->close();
        $conexion->close();
    }
}
?>