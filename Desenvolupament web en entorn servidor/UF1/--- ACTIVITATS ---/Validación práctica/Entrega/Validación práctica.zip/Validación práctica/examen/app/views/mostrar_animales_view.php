<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Animales</title>
    <link rel="stylesheet" href="../../public/css/mostrar_animales_view.css">
</head>
<body>
    <div class="contenedor">
        <h1>Animales</h1>
            <table>
                <thead>
                    <tr>
                        <th>id_animal</th>
                        <th>especie</th>
                        <th>nombre</th>
                        <th>fecha nacimiento</th>
                        <th>peso</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        require_once '../controllers/animales_controller.php';
                        foreach($animales as $animal) {
                            echo "<tr>";
                            echo "<td>". $animal['id_animal'] ."</td>";
                            echo "<td>". $animal['especie'] ."</td>";
                            echo "<td>". $animal['nombre'] ."</td>";
                            echo "<td>". $animal['fecha_nacimiento'] ."</td>";
                            echo "<td>". $animal['peso'] ."</td>";
                            echo "</tr>";
                        }
                    ?>
                </tbody>
            </table>
    </div>
    <button id="volver" onclick="window.location.href = 'index.php';">Volver</button>
</body>
</html>