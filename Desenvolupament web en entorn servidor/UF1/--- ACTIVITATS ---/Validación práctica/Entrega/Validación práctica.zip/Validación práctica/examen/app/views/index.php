<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Index</title>
    <link rel="icon" href="../../public/img/index.png" type="image/x-icon">
    <link rel="stylesheet" href="../../public/css/index.css">
</head>
<body>
    <div class="contenedor">
        <h1>Index</h1>
        <button onclick="window.location.href = 'crear_animal_view.php';">Crear animal</button><br>
        <button onclick="window.location.href = 'modificar_animal_view.php';">Modificar animal</button><br>
        <button onclick="window.location.href = 'mostrar_animales_view.php';">Mostrar animales</button><br>
        <button onclick="window.location.href = 'eliminar_animal_view.php';">Eliminar animal</button><br>
    </div>
</body>
</html>