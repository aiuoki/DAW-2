<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eliminar Animal</title>
    <link rel="stylesheet" href="../../public/css/eliminar_animal_view.css">
</head>
<body>
    <div class="contenedor">
        <h1>Eliminar Animal</h1>
        <form action="../controllers/animales_controller.php" method="post">
            <select name="id_animal" required>
                <option value="">Seleccione el id de un animal</option>
                <?php
                    require_once '../controllers/animales_controller.php';
                    // Recorrer los animales y crear una opción para cada uno
                    foreach ($animales as $animal) {
                        echo "<option value='". $animal['id_animal'] ."'>". $animal['id_animal'] ."</option>";
                    }
                ?>
            </select>
            <button type="submit" name="eliminar">Eliminar</button>
        </form>
        <button id="volver" onclick="window.location.href = 'index.php';">Volver</button>
    </div>
</body>
</html>