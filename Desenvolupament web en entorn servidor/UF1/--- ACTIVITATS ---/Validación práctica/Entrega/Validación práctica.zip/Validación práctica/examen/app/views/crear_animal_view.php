<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nuevo Animal</title>
    <link rel="stylesheet" href="../../public/css/crear_animal_view.css">
</head>
<body>
    <div class="contenedor">
        <h1>Nuevo Animal</h1>
        <form action="../controllers/animales_controller.php" method="post">
            <input type="text" name="especie" pattern="[A-Za-z]+" maxlength="30" placeholder="especie" required>
            <input type="text" name="nombre" maxlength="30" placeholder="nombre" required>
            <input type="text" name="fecha_nacimiento" maxlength="10" placeholder="fecha nacimiento" required>
            <input type="text" name="peso" pattern="[0-9]+" maxlength="4" placeholder="peso" required>
            <button type="submit" name="crear">Crear</button>
        </form>
        <button id="volver" onclick="window.location.href = 'index.php';">Volver</button>
    </div>
</body>
</html>