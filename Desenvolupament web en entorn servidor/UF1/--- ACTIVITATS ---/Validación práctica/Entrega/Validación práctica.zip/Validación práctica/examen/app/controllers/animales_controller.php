<?php
// Incluir el archivo animales_model.php
require_once '../models/animales_model.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Obtener los datos enviados por el formulario
    $id_animal = $_POST['id_animal'];
    $especie = $_POST['especie'];
    $nombre = $_POST['nombre'];
    $fecha_nacimiento = $_POST['fecha_nacimiento'];
    $peso = $_POST['peso'];

    if (isset($_POST['crear'])) {
        // Crear un nuevo curso utilizando la función crearAnimal del modelo
        AnimalesModel::crearAnimal($especie, $nombre, $fecha_nacimiento, $peso);
    }
    if (isset($_POST['modificar'])) {
        // Modificar un curso utilizando la función modificarAnimal del modelo
        AnimalesModel::modificarAnimal($id_animal, $especie, $nombre, $fecha_nacimiento, $peso);
    }
    if (isset($_POST['eliminar'])) {
        // Eliminar un curso utilizando la función eliminarAnimal del modelo
        AnimalesModel::eliminarAnimal($id_animal);
    }
    
    // Redirigir al usuario a otra página
    header('Location: ../views/mostrar_animales_view.php');
    exit;
} else {
    // Obtener todos los animales utilizando la función mostrarAnimales del modelo
    $animales = AnimalesModel::mostrarAnimales();
}
?>