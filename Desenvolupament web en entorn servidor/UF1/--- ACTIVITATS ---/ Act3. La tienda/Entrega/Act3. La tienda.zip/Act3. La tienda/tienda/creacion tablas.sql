CREATE TABLE USUARIOS (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    nick VARCHAR(255),
    email VARCHAR(255),
    contrasenia VARCHAR(255),
    admin BOOLEAN DEFAULT 0
);

CREATE TABLE CATEGORIAS (
    id_categoria INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(255),
    descripcion VARCHAR(255)
);

CREATE TABLE PRODUCTOS (
    id_producto INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(255),
    stock INT,
    precio_unitario DECIMAL(10,2),
    categoria INT,
    FOREIGN KEY (categoria) REFERENCES CATEGORIAS(id_categoria) ON DELETE CASCADE
);

CREATE TABLE CARRITOS (
    id_carrito INT AUTO_INCREMENT PRIMARY KEY,
    producto INT,
    cantidad INT,
    precio_total DECIMAL(10,2),
    usuario INT,
    FOREIGN KEY (producto) REFERENCES PRODUCTOS(id_producto) ON DELETE CASCADE,
    FOREIGN KEY (usuario) REFERENCES USUARIOS(id_usuario)
);