<?php
require_once("db/db.php");
require_once("controllers/personas_controller.php");
?>
