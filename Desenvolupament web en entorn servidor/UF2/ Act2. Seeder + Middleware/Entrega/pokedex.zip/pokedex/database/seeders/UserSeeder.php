<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Creamos un usuario administrador de prueba
        DB::table('users')->insert([
            'name' => 'Sandra',
            'email' => 'sandy@mail.com',
            'password' => bcrypt('123'),
            'rol' => 'administrador'
        ]);
        // Creamos un usuario normal de prueba
        DB::table('users')->insert([
            'name' => 'Daniel',
            'email' => 'dan@mail.com',
            'password' => bcrypt('123'),
            'rol' => 'usuario'
        ]);
    }
}
