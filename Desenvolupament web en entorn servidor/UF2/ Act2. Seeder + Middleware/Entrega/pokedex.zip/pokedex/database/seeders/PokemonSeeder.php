<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB; //libreria nos permite hacer insert
use Illuminate\Support\Str; //liberaria para funciones str

class PokemonSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $nombres = [
            "Bulbasaur", "Ivysaur", "Venusaur", "Charmander", "Charmeleon", 
            "Charizard", "Squirtle", "Wartortle", "Blastoise", "Caterpie", 
            "Metapod", "Butterfree", "Weedle", "Kakuna", "Beedrill", 
            "Pidgey", "Pidgeotto", "Pidgeot", "Rattata", "Raticate", 
            "Spearow", "Fearow", "Ekans", "Arbok", "Pikachu", 
            "Raichu", "Sandshrew", "Sandslash", "Nidoran", "Nidorina", 
            "Nidoqueen", "Nidoran", "Nidorino", "Nidoking", "Clefairy", 
            "Clefable", "Vulpix", "Ninetales", "Jigglypuff", "Wigglytuff", 
            "Zubat", "Golbat", "Oddish", "Gloom", "Vileplume", 
            "Paras", "Parasect", "Venonat", "Venomoth", "Diglett", 
            "Dugtrio"
        ];
        $tipos = [
            "acero",
            "agua",
            "bicho",
            "dragon",
            "electrico",
            "fantasma",
            "fuego",
            "hada",
            "hielo",
            "lucha",
            "normal",
            "planta",
            "psiquico",
            "roca",
            "siniestro",
            "tierra",
            "veneno",
            "volador"
        ];
        $tamanios = [
            "grande",
            "mediano",
            "pequenio"
        ];
        //inserta 10 pokemons
        for($i =0; $i<10; $i++)
        {
            //genera un tamaño aleatorio
            $tamanioAleatorio = $tamanios[array_rand($tamanios)];
            $peso = 0;
        
            //genera un peso aleatorio dependiendo del tamaño
            if ($tamanioAleatorio == "pequenio") {
                $peso = mt_rand(1, 300) / 10;
            } else if ($tamanioAleatorio == "mediano") {
                $peso = mt_rand(301, 700) / 10;
            } else if ($tamanioAleatorio == "grande") {
                $peso = mt_rand(701, 9999) / 10;
            }
        
            //inserta un pokemon con los datos aleatorios
            DB::table('pokemons')->insert([
                'nombre' => $nombres[array_rand($nombres)],
                'tipo' => $tipos[array_rand($tipos)],
                'tamanio' => $tamanioAleatorio,
                'peso' => $peso
            ]);
        }
    }
}
