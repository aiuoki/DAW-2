<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <h1>Login</h1>
    <div>
        <!-- Mostramos los mensajes de error -->
        @if(session('error'))
            <div>{{session('error')}}</div><br>
        @endif
        <!-- Mostramos los errores de validación -->
        @if($errors->any())
            <ul>
                @foreach($errors->all() as $error)
                    <li>{{$error}}</li>
                @endforeach
            </ul>
        @endif
    </div>
    <form method="post" action="{{route('auth')}}"> <!-- Formulario para iniciar sesión -->
        @csrf
        @method('post')
        <div>
            <label>Email</label><br>
            <input type="text" name="email" placeholder="Email">
        </div><br>
        <div>
            <label>Password</label><br>
            <input type="password" name="password" placeholder="Password">
        </div><br>
        
        <input type="submit" value="Login">
    </form>
</body>
</html>