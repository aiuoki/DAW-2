<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Edita un Pokemon</h1>
    <div>
        <!-- Mostramos los errores de validación -->
        @if($errors->any())
            <ul>
                @foreach($errors->all() as $error)
                    <li>{{$error}}</li>
                @endforeach
            </ul>
        @endif
    </div>
    <div>
        <a href="{{route('pokemon.administrador.index')}}">Volver al Index</a> <!-- Creamos un enlace para volver al index -->
    </div><br>
    <!-- Creamos un formulario para editar un pokemon -->
    <form method="post" action="{{route('pokemon.administrador.update', ['pokemon' => $pokemon])}}">
        @csrf
        @method('put')
        <div>
            <label>Nombre</label>
            <input type="text" name="nombre" placeholder="nombre" value="{{$pokemon->nombre}}">
        </div>
        <div>
            <label>Tipo</label>
            <select name="tipo">
                <option value=""></option>
                <option value="acero" {{ $pokemon->tipo == 'acero' ? 'selected' : '' }}>Acero</option>
                <option value="agua" {{ $pokemon->tipo == 'agua' ? 'selected' : '' }}>Agua</option>
                <option value="bicho" {{ $pokemon->tipo == 'bicho' ? 'selected' : '' }}>Bicho</option>
                <option value="dragon" {{ $pokemon->tipo == 'dragon' ? 'selected' : '' }}>Dragón</option>
                <option value="electrico" {{ $pokemon->tipo == 'electrico' ? 'selected' : '' }}>Eléctrico</option>
                <option value="fantasma" {{ $pokemon->tipo == 'fantasma' ? 'selected' : '' }}>Fantasma</option>
                <option value="fuego" {{ $pokemon->tipo == 'fuego' ? 'selected' : '' }}>Fuego</option>
                <option value="hada" {{ $pokemon->tipo == 'hada' ? 'selected' : '' }}>Hada</option>
                <option value="hielo" {{ $pokemon->tipo == 'hielo' ? 'selected' : '' }}>Hielo</option>
                <option value="lucha" {{ $pokemon->tipo == 'lucha' ? 'selected' : '' }}>Lucha</option>
                <option value="normal" {{ $pokemon->tipo == 'normal' ? 'selected' : '' }}>Normal</option>
                <option value="planta" {{ $pokemon->tipo == 'planta' ? 'selected' : '' }}>Planta</option>
                <option value="psiquico" {{ $pokemon->tipo == 'psiquico' ? 'selected' : '' }}>Psíquico</option>
                <option value="roca" {{ $pokemon->tipo == 'roca' ? 'selected' : '' }}>Roca</option>
                <option value="siniestro" {{ $pokemon->tipo == 'siniestro' ? 'selected' : '' }}>Siniestro</option>
                <option value="tierra" {{ $pokemon->tipo == 'tierra' ? 'selected' : '' }}>Tierra</option>
                <option value="veneno" {{ $pokemon->tipo == 'veneno' ? 'selected' : '' }}>Veneno</option>
                <option value="volador" {{ $pokemon->tipo == 'volador' ? 'selected' : '' }}>Volador</option>
            </select>
        </div>
        <div>
            <label>Tamaño</label>
            <select name="tamanio">
                <option value=""></option>
                <option value="grande" {{ $pokemon->tamanio == 'grande' ? 'selected' : '' }}>Grande</option>
                <option value="mediano" {{ $pokemon->tamanio == 'mediano' ? 'selected' : '' }}>Mediano</option>
                <option value="pequenio" {{ $pokemon->tamanio == 'pequenio' ? 'selected' : '' }}>Pequeño</option>
            </select>
        </div>
        <div>
            <label>Peso</label>
            <input type="number" name="peso" placeholder="peso" value="{{$pokemon->peso}}">
        </div><br>

        <div>
            <input type="submit" value="Actualizar Pokemon">
        </div>
    </form>
</body>
</html>