<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Pokemon</h1>
    <div>
        <!-- Mostramos los mensajes de éxito -->
        @if(session()->has('success'))
            <div>{{session('success')}}</div><br>
        @endif

        <!-- Mostramos los mensajes de error -->
        @if(session('error'))
            <div>{{session('error')}}</div><br>
        @endif
    </div>
    <div>
        <table border="1">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Tipo</th>
                    <th>Tamaño</th>
                    <th>Peso</th>
                </tr>
            </thead>
            <tbody>
                <!-- Recorremos los pokemons y mostramos sus datos -->
                @foreach($pokemons as $pokemon)
                    <tr>
                        <td>{{$pokemon->id}}</td>
                        <td>{{$pokemon->nombre}}</td>
                        <td>{{$pokemon->tipo}}</td>
                        <td>{{$pokemon->tamanio}}</td>
                        <td>{{$pokemon->peso}}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div><br>
    <!-- Creamos un formulario para cerrar sesión -->
    <form method="post" action="{{route('logout')}}" onsubmit="return confirm('¿Estás seguro de que quieres cerrar la sesión?');">
        @csrf
        <button type="submit">Logout</button>
    </form>
</body>
</html>