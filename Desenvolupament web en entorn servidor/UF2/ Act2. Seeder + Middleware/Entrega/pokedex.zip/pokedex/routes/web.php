<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PokemonController;
use App\Http\Controllers\AuthController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', [AuthController::class, 'login'])->name('login');
Route::post('/auth', [AuthController::class, 'auth'])->name('auth');
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

Route::middleware(['UsuarioMiddleware'])->group(function () {
    Route::get('/pokemon/usuario', [PokemonController::class, 'index'])->name('pokemon.usuario.index');
});

Route::middleware(['AdministradorMiddleware'])->group(function () {
    Route::get('/pokemon/administrador', [PokemonController::class, 'index'])->name('pokemon.administrador.index');
    Route::get('/pokemon/create', [PokemonController::class, 'create'])->name('pokemon.administrador.create');
    Route::post('/pokemon', [PokemonController::class, 'store'])->name('pokemon.administrador.store');
    Route::get('/pokemon/{pokemon}/edit', [PokemonController::class, 'edit'])->name('pokemon.administrador.edit');
    Route::put('/pokemon/{pokemon}/update', [PokemonController::class, 'update'])->name('pokemon.administrador.update');
    Route::delete('/pokemon/{pokemon}/destroy', [PokemonController::class, 'destroy'])->name('pokemon.administrador.destroy');
});