<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Pokemon</h1>
    <div>
        <!-- Mostramos los mensajes de éxito -->
        <?php if(session()->has('success')): ?>
            <div><?php echo e(session('success')); ?></div><br>
        <?php endif; ?>

        <!-- Mostramos los mensajes de error -->
        <?php if(session('error')): ?>
            <div><?php echo e(session('error')); ?></div><br>
        <?php endif; ?>
    </div>
    <div>
        <table border="1">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Tipo</th>
                    <th>Tamaño</th>
                    <th>Peso</th>
                </tr>
            </thead>
            <tbody>
                <!-- Recorremos los pokemons y mostramos sus datos -->
                <?php $__currentLoopData = $pokemons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pokemon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($pokemon->id); ?></td>
                        <td><?php echo e($pokemon->nombre); ?></td>
                        <td><?php echo e($pokemon->tipo); ?></td>
                        <td><?php echo e($pokemon->tamanio); ?></td>
                        <td><?php echo e($pokemon->peso); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div><br>
    <!-- Creamos un formulario para cerrar sesión -->
    <form method="post" action="<?php echo e(route('logout')); ?>" onsubmit="return confirm('¿Estás seguro de que quieres cerrar la sesión?');">
        <?php echo csrf_field(); ?>
        <button type="submit">Logout</button>
    </form>
</body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/pokedex/resources/views/pokemons/usuario/index.blade.php ENDPATH**/ ?>