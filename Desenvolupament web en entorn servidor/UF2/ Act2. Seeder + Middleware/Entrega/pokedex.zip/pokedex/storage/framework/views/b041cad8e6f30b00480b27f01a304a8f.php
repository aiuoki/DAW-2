<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Pokemon</h1>
    <div>
        <?php if(session()->has('success')): ?>
            <div>
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
    </div>
    <div>
        <div>
            <a href="<?php echo e(route('pokemon.create')); ?>">Crear un Pokemon</a>
        </div>
        <table border="1">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Tipo</th>
                    <th>Tamaño</th>
                    <th>Peso</th>
                    <th>Editar</th>
                    <th>Eliminar</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $pokemons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pokemon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($pokemon->id); ?></td>
                        <td><?php echo e($pokemon->nombre); ?></td>
                        <td><?php echo e($pokemon->tipo); ?></td>
                        <td><?php echo e($pokemon->tamanio); ?></td>
                        <td><?php echo e($pokemon->peso); ?></td>
                        <td>
                            <a href="<?php echo e(route('pokemon.edit', ['pokemon' => $pokemon])); ?>">Editar</a>
                        </td>
                        <td>
                            <form method="post" action="<?php echo e(route('pokemon.destroy', ['pokemon' => $pokemon])); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <input type="submit" value="Eliminar">
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/pokedex/resources/views/pokemons/index.blade.php ENDPATH**/ ?>