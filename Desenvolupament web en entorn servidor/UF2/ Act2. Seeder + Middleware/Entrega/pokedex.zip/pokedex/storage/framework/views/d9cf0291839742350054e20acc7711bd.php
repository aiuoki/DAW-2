<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Edita un Pokemon</h1>
    <div>
        <?php if($errors->any()): ?>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>
    </div>
    <div>
        <a href="<?php echo e(route('pokemon.index')); ?>">Volver al Index</a>
    </div>
    <form method="post" action="<?php echo e(route('pokemon.update', ['pokemon' => $pokemon])); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
        <div>
            <label>Nombre</label>
            <input type="text" name="nombre" placeholder="nombre" value="<?php echo e($pokemon->nombre); ?>">
        </div>
        <div>
            <label>Tipo</label>
            <select name="tipo">
                <option value=""></option>
                <option value="acero" <?php echo e($pokemon->tipo == 'acero' ? 'selected' : ''); ?>>Acero</option>
                <option value="agua" <?php echo e($pokemon->tipo == 'agua' ? 'selected' : ''); ?>>Agua</option>
                <option value="bicho" <?php echo e($pokemon->tipo == 'bicho' ? 'selected' : ''); ?>>Bicho</option>
                <option value="dragon" <?php echo e($pokemon->tipo == 'dragon' ? 'selected' : ''); ?>>Dragón</option>
                <option value="electrico" <?php echo e($pokemon->tipo == 'electrico' ? 'selected' : ''); ?>>Eléctrico</option>
                <option value="fantasma" <?php echo e($pokemon->tipo == 'fantasma' ? 'selected' : ''); ?>>Fantasma</option>
                <option value="fuego" <?php echo e($pokemon->tipo == 'fuego' ? 'selected' : ''); ?>>Fuego</option>
                <option value="hada" <?php echo e($pokemon->tipo == 'hada' ? 'selected' : ''); ?>>Hada</option>
                <option value="hielo" <?php echo e($pokemon->tipo == 'hielo' ? 'selected' : ''); ?>>Hielo</option>
                <option value="lucha" <?php echo e($pokemon->tipo == 'lucha' ? 'selected' : ''); ?>>Lucha</option>
                <option value="normal" <?php echo e($pokemon->tipo == 'normal' ? 'selected' : ''); ?>>Normal</option>
                <option value="planta" <?php echo e($pokemon->tipo == 'planta' ? 'selected' : ''); ?>>Planta</option>
                <option value="psiquico" <?php echo e($pokemon->tipo == 'psiquico' ? 'selected' : ''); ?>>Psíquico</option>
                <option value="roca" <?php echo e($pokemon->tipo == 'roca' ? 'selected' : ''); ?>>Roca</option>
                <option value="siniestro" <?php echo e($pokemon->tipo == 'siniestro' ? 'selected' : ''); ?>>Siniestro</option>
                <option value="tierra" <?php echo e($pokemon->tipo == 'tierra' ? 'selected' : ''); ?>>Tierra</option>
                <option value="veneno" <?php echo e($pokemon->tipo == 'veneno' ? 'selected' : ''); ?>>Veneno</option>
                <option value="volador" <?php echo e($pokemon->tipo == 'volador' ? 'selected' : ''); ?>>Volador</option>
            </select>
        </div>
        <div>
            <label>Tamaño</label>
            <select name="tamanio">
                <option value=""></option>
                <option value="grande" <?php echo e($pokemon->tamanio == 'grande' ? 'selected' : ''); ?>>Grande</option>
                <option value="mediano" <?php echo e($pokemon->tamanio == 'mediano' ? 'selected' : ''); ?>>Mediano</option>
                <option value="pequenio" <?php echo e($pokemon->tamanio == 'pequenio' ? 'selected' : ''); ?>>Pequeño</option>
            </select>
        </div>
        <div>
            <label>Peso</label>
            <input type="number" name="peso" placeholder="peso" value="<?php echo e($pokemon->peso); ?>">
        </div>
        <div>
            <input type="submit" value="Actualizar Pokemon">
        </div>
    </form>
</body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/pokedex/resources/views/pokemons/edit.blade.php ENDPATH**/ ?>