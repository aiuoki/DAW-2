<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Crea un Pokemon</h1>
    <div>
        <!-- Mostramos los errores de validación -->
        <?php if($errors->any()): ?>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>
    </div>
    <div>
        <a href="<?php echo e(route('pokemon.administrador.index')); ?>">Volver al Index</a> <!-- Creamos un enlace para volver al index -->
    </div><br>
    <!-- Creamos un formulario para crear un pokemon -->
    <form method="post" action="<?php echo e(route('pokemon.administrador.store')); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('post'); ?>
        <div>
            <label>Nombre</label>
            <input type="text" name="nombre" placeholder="nombre">
        </div>
        <div>
            <label>Tipo</label>
            <select name="tipo">
                <option value=""></option>
                <option value="acero">Acero</option>
                <option value="agua">Agua</option>
                <option value="bicho">Bicho</option>
                <option value="dragon">Dragón</option>
                <option value="electrico">Eléctrico</option>
                <option value="fantasma">Fantasma</option>
                <option value="fuego">Fuego</option>
                <option value="hada">Hada</option>
                <option value="hielo">Hielo</option>
                <option value="lucha">Lucha</option>
                <option value="normal">Normal</option>
                <option value="planta">Planta</option>
                <option value="psiquico">Psíquico</option>
                <option value="roca">Roca</option>
                <option value="siniestro">Siniestro</option>
                <option value="tierra">Tierra</option>
                <option value="veneno">Veneno</option>
                <option value="volador">Volador</option>
            </select>
        </div>
        <div>
            <label>Tamaño</label>
            <select name="tamanio">
                <option value=""></option>
                <option value="grande">Grande</option>
                <option value="mediano">Mediano</option>
                <option value="pequenio">Pequeño</option>
            </select>
        </div>
        <div>
            <label>Peso</label>
            <input type="text" name="peso" placeholder="peso">
        </div><br>

        <div>
            <input type="submit" value="Crear un nuevo Pokemon">
        </div>
    </form>
</body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/pokedex/resources/views/pokemons/administrador/create.blade.php ENDPATH**/ ?>