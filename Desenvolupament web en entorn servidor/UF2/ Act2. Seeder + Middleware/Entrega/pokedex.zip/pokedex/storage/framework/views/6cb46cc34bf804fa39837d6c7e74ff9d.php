<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <h1>Login</h1>
    <div>
        <!-- Mostramos los mensajes de error -->
        <?php if(session('error')): ?>
            <div><?php echo e(session('error')); ?></div><br>
        <?php endif; ?>
        <!-- Mostramos los errores de validación -->
        <?php if($errors->any()): ?>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>
    </div>
    <form method="post" action="<?php echo e(route('auth')); ?>"> <!-- Formulario para iniciar sesión -->
        <?php echo csrf_field(); ?>
        <?php echo method_field('post'); ?>
        <div>
            <label>Email</label><br>
            <input type="text" name="email" placeholder="Email">
        </div><br>
        <div>
            <label>Password</label><br>
            <input type="password" name="password" placeholder="Password">
        </div><br>
        
        <input type="submit" value="Login">
    </form>
</body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/pokedex/resources/views/login.blade.php ENDPATH**/ ?>