<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class AdministradorMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        if(auth()->user() == null) { // Si no hay usuario logueado redirige a la página de login con un mensaje de error
            return redirect(route('login'))->with('error', 'Error: Pagina no encontrada.');
        }  else if(auth()->user()->rol == 'usuario') { // Si el usuario logueado es un usuario normal redirige al index del usuario con un mensaje de error
            return redirect(route('pokemon.usuario.index'))->with('error', 'Error: No tienes permisos para acceder a esta página.');
        } else if(auth()->user()->rol == 'administrador') { // Si el usuario logueado es un administrador permite el acceso a la página
            return $next($request);
        } else { // Si el usuario logueado no tiene un rol definido redirige a la página de login con un mensaje de error
            return redirect(route('login'))->with('error', 'Error: Pagina no encontrada.');
        }
    }
}
