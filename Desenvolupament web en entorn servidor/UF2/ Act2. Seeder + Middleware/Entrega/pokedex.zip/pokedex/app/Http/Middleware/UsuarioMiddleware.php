<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class UsuarioMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        if(auth()->user() == null) { // Si no hay usuario logueado redirige a la página de login con un mensaje de error
            return redirect(route('login'))->with('error', 'Error: Pagina no encontrada.');
        } else if(auth()->user()->rol == 'administrador') { // Si el usuario logueado es un administrador redirige al index del administrador con un mensaje de error
            return redirect(route('pokemon.administrador.index'))->with('error', 'Error: Conectese con el un usuario normal para ver la pagina.');
        } else if(auth()->user()->rol == 'usuario') { // Si el usuario logueado es un usuario normal permite el acceso a la página
            return $next($request);
        } else { // Si el usuario logueado no tiene un rol definido redirige a la página de login con un mensaje de error
            return redirect(route('login'))->with('error', 'Error: Pagina no encontrada.');
        }
    }
}
