<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pokemon;

class PokemonController extends Controller
{   
    public function index() { // Método que muestra el index de pokemons
        $pokemons = Pokemon::all(); // Obtenemos todos los pokemons
        if(auth()->user()->rol == 'administrador') { // Si el usuario es un administrador redirige al index del administrador
            return view('pokemons.administrador.index', ['pokemons' => $pokemons]);
        } else if(auth()->user()->rol == 'usuario') { // Si el usuario es un usuario normal redirige al index del usuario
            return view('pokemons.usuario.index', ['pokemons' => $pokemons]);
        }
    }

    public function create() { // Método que devuelve la vista para crear un pokemon
        return view('pokemons.administrador.create');
    }

    public function store(Request $request) { // Método que almacena un pokemon
        // Validamos los datos del formulario
        $data = $request->validate([
            'nombre' => 'required',
            'tipo' => 'required',
            'tamanio' => 'nullable|in:grande,mediano,pequenio',
            'peso' => 'nullable|numeric|between:0,999.9|regex:/^\d+(\.\d{1})?$/'
        ]);

        $newPokemon = Pokemon::create($data); // Creamos un nuevo pokemon

        // Redirigimos al index de pokemons con un mensaje de éxito
        return redirect(route('pokemon.administrador.index'))->with('success', 'Pokemon creado correctamente');
    }

    public function edit(Pokemon $pokemon) { // Método que devuelve la vista para editar un pokemon
        return view('pokemons.administrador.edit', ['pokemon' => $pokemon]);
    }

    public function update(Pokemon $pokemon, Request $request) { // Método que actualiza un pokemon
        // Validamos los datos del formulario
        $data = $request->validate([
            'nombre' => 'required',
            'tipo' => 'required',
            'tamanio' => 'nullable|in:grande,mediano,pequenio',
            'peso' => 'nullable|numeric|between:0,999.9|regex:/^\d+(\.\d{1})?$/'
        ]);

        $pokemon->update($data); // Actualizamos el pokemon

        // Redirigimos al index de pokemons con un mensaje de éxito
        return redirect(route('pokemon.administrador.index'))->with('success', 'Pokemon actualizado correctamente');
    }

    public function destroy(Pokemon $pokemon) { // Método que elimina un pokemon
        $pokemon->delete(); // Eliminamos el pokemon

        // Redirigimos al index de pokemons con un mensaje de éxito
        return redirect(route('pokemon.administrador.index'))->with('success', 'Pokemon eliminado correctamente');
    }
}
