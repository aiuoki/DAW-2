<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function login() {
        return view('login');
    }

    public function auth(Request $request) { // Método que autentica al usuario
        // Validamos los datos del formulario
        $credentials = $request->validate([
            'email' => 'required|email',
            'password' => 'required'
        ]);

        // Buscamos al usuario en la base de datos
        $user = User::where('email', $credentials['email'])->first();

        if($user && password_verify($credentials['password'], $user->password)) { // Si el usuario existe y la contraseña es correcta
            Auth::login($user); // Logueamos al usuario
            
            if($user->rol == 'administrador') { // Si el usuario es un administrador redirige al index del administrador y muestra un mensaje de éxito
                return redirect(route('pokemon.administrador.index'))->with('success', 'Administrador Logueado Correctamente');
            } else if($user->rol == 'usuario') { // Si el usuario es un usuario normal redirige al index del usuario y muestra un mensaje de éxito
                return redirect(route('pokemon.usuario.index'))->with('success', 'Usuario Logueado Correctamente');
            }
        } else { // Si el usuario no existe o la contraseña es incorrecta redirige a la página de login con un mensaje de error
            return redirect(route('login'))->with('error', 'Usuario o Contraseña Incorrectos');
        }
    }

    public function logout() { // Método que cierra la sesión del usuario y redirige a la página de login
        Auth::logout();
        return redirect(route('login'));
    }
}
