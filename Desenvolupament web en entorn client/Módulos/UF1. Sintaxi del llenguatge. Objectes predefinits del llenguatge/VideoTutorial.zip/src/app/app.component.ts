import { Component } from '@angular/core';
import { ListaFotos } from './models/lista-fotos.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'VideoTutorial';
  tipo = "Terror";

  listas: ListaFotos[] = [
    { titulo: "Lista Terror", categoria: "Terror" },
    { titulo: "Lista Ciencia", categoria: "Ciencia" },
    { titulo: "Lista Comedia", categoria: "Comedia" }
  ];

  esElMismoTipo(lista: ListaFotos): boolean {
    return this.tipo == lista.categoria;
  }


}
