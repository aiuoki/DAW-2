export interface Foto {
    titulo: string;
    imagen: string;
    descripcion: string;
    fecha: Date;
    precio?: number;
}