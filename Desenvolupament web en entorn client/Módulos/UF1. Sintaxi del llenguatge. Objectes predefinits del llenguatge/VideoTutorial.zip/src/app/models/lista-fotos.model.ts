export interface ListaFotos {
    titulo: string;
    categoria: string;
}