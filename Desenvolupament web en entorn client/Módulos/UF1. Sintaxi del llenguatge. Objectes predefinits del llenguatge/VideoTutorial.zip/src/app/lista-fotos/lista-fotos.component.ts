import { Component } from '@angular/core';
import { Foto } from '../models/foto.model';

@Component({
  selector: 'app-lista-fotos',
  templateUrl: './lista-fotos.component.html',
  styleUrls: ['./lista-fotos.component.css']
})
export class ListaFotosComponent {

  data = Date.now();

  fotos: Foto[] = [
    { titulo: "Titulo 1", imagen: "https://picsum.photos/200/300", descripcion: "Descripcion Foto 1", fecha: new Date(), precio: 23.4 },
    { titulo: "Titulo 2", imagen: "https://picsum.photos/200/200", descripcion: "Descripcion Foto 2", fecha: new Date() },
    { titulo: "Titulo 3", imagen: "https://picsum.photos/200/150", descripcion: "Descripcion Foto 3", fecha: new Date() },
    { titulo: "Titulo 4", imagen: "https://picsum.photos/200/200", descripcion: "Descripcion Foto 4", fecha: new Date() }
  ];

  cambiarFoto(foto: Foto) {
    console.log(foto);
    foto.imagen = "https://picsum.photos/400/400";
  }

}
