import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  // Primera parte
  title: string = 'El botón se ha apretado 0 veces';
  veces: number = 0;

  changeTitle(): void {
    this.veces++;
    this.title = `El botón se ha apretado ${this.veces} veces`;
  }

  // Segunda parte
  texto: string = '';

}
