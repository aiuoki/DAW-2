import { Component } from '@angular/core';
import {Article} from "../../models/article.model";

@Component({
  selector: 'app-articulos',
  templateUrl: './articulos.component.html',
  styleUrls: ['./articulos.component.css']
})
export class ArticulosComponent {

  constructor() {

  }
}
