import { Component, EventEmitter, Output } from '@angular/core';
import { AbstractControl, FormControl, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';

@Component({
  selector: 'app-register-form',
  templateUrl: './register-form.component.html',
  styleUrls: ['./register-form.component.css']
})
export class RegisterFormComponent {

  registerForm: FormGroup;
  @Output() backEvent = new EventEmitter<void>();

  constructor() {
    this.registerForm = new FormGroup({
      email: new FormControl('', [Validators.required, Validators.email]),
      name: new FormControl('', [Validators.required]),
      surname: new FormControl('', [Validators.required]),
      phone: new FormControl('', [Validators.required, Validators.pattern('[0-9]{9}')]),
      password: new FormControl('', [Validators.required, Validators.minLength(5), Validators.maxLength(8)])
    });

    // Añadimos este controlador aquí debido que necesitamos inicializar previamente la variable registerForm
    this.registerForm.addControl('repassword', new FormControl('',
      [Validators.required,
       passwordMatchValidator(this.registerForm.controls['password'])]));
  }

  onSubmit() {
    console.log(this.registerForm.value);
  }

  onBackPressed() {
    this.backEvent.emit();
  }

}

export function passwordMatchValidator(password: AbstractControl): ValidatorFn {
  return (control:AbstractControl) : ValidationErrors | null => {

      const value = control.value;

      if (!value) {
          return null;
      }

      const passwordValid = password.value === control.value;

      return !passwordValid ? {passwordMatch:true}: null;
  }
}
