import { Component, Input } from '@angular/core';
import { Foto } from '../models/foto.model';

@Component({
  selector: 'app-foto',
  templateUrl: './foto.component.html',
  styleUrls: ['./foto.component.css']
})
export class FotoComponent {

  @Input() foto: Foto | null = null;
  editando: boolean = false;
  
}
