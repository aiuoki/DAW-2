import { Component, Input, OnInit } from '@angular/core';
import { Tarea } from "../../models/tarea-model";

@Component({
  selector: 'app-tarea',
  templateUrl: './tarea.component.html',
  styleUrls: ['./tarea.component.css']
})
export class TareaComponent implements OnInit {
  @Input() tarea:Tarea;

  constructor() {
    this.tarea = {id: 0, lista: "", img: "", titulo: "", usuarios: [], fechaFin: new Date()};
  }

  ngOnInit(): void {
  }

  colorFondoFecha(): string | undefined {
    if (this.tarea.fechaFin === null) {
        return undefined;
    }

    const fechaFin = new Date(this.tarea.fechaFin);
    const fechaActual = new Date();

    if ((fechaFin < fechaActual) && this.tarea.lista !== 'Finalizadas') {
      return 'rgb(231, 0, 3)';
    } else if ((fechaFin < fechaActual) && this.tarea.lista === 'Finalizadas') {
      return 'rgb(0, 180, 10)';
    } else if ((fechaFin.getTime() - fechaActual.getTime()) <= 24 * 60 * 60 * 1000) {
      return 'rgb(246, 167, 11)';
    } else {
      return 'rgb(128, 127, 127)';
    }
  }

}
