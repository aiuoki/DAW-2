export interface Usuario {
  email: string;
  img: string;
  nick: string;
  alt: string;
}