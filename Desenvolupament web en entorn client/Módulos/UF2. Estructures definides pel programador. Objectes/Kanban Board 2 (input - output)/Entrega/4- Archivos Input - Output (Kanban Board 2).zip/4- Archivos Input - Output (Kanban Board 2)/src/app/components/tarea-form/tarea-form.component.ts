import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Form, FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Tarea } from 'src/app/models/tarea-model';
import { Usuario } from 'src/app/models/usuario-model';

@Component({
  selector: 'app-tarea-form',
  templateUrl: './tarea-form.component.html',
  styleUrls: ['./tarea-form.component.css']
})
export class TareaFormComponent implements OnInit {

  formTarea: FormGroup;

  @Input() listaSeleccionada: string | null = null;
  @Input() tareaSeleccionada: Tarea | null = null;
  
  @Output() tarea: EventEmitter<Tarea> = new EventEmitter<Tarea>();
  @Output() ocultarForm = new EventEmitter<void>();

  constructor(private fb: FormBuilder) {
    this.formTarea = this.fb.group({
      id: [null],
      titulo: [null, Validators.required],
      lista: [null, [Validators.required, Validators.pattern('Pendientes|Progreso|Finalizadas')]],
      fechaFin: [null],
      img: [null],
      usuarios: [[] as Usuario[]]
    });
  }

  ngOnInit(): void {
    if(this.tareaSeleccionada == null) {
      // Nueva tarea
      this.formTarea.patchValue({
        lista: this.listaSeleccionada
      });
    } else {
      // Modificar tarea
      this.formTarea.patchValue({
        id: this.tareaSeleccionada.id,
        titulo: this.tareaSeleccionada.titulo,
        lista: this.tareaSeleccionada.lista,
        fechaFin: this.tareaSeleccionada.fechaFin,
        img: this.tareaSeleccionada.img,
        usuarios: this.tareaSeleccionada.usuarios
      });
    }
  }

  usuarioPrueba: Usuario = {
    email: 'dceban@ilerna.com',
    img: 'https://picsum.photos/150/150',
    nick: 'Daniel',
    alt: 'Usuario'
  };

  usuarioPrueba2: Usuario = {
    email: 'xzhou@ilerna.com',
    img: 'https://picsum.photos/160/160',
    nick: 'Xiaobin',
    alt: 'Usuario'
  };

  guardarTarea() {
    this.tarea.emit(this.formTarea.value);
    this.ocultarForm.emit();
  }

  eliminarUsuario(usuario: Usuario) {
    let usuarios = [...this.formTarea.controls['usuarios'].value];
    let index = usuarios.indexOf(usuario);
    if (index > -1) {
      usuarios.splice(index, 1);
      this.formTarea.controls['usuarios'].setValue(usuarios);
    }
  }

  agregarUsuario() {
    let usuarios = [...this.formTarea.controls['usuarios'].value];
    if (usuarios.some((user: Usuario) => user.email === this.usuarioPrueba.email)) {
      usuarios.push(this.usuarioPrueba2);
    } else {
      usuarios.push(this.usuarioPrueba);
    }
    this.formTarea.controls['usuarios'].setValue(usuarios);
  }

}