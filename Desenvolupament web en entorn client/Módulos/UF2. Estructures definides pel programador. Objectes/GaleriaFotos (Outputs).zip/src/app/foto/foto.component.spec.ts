import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FotosComponent } from './foto.component';

describe('FotosComponent', () => {
  let component: FotosComponent;
  let fixture: ComponentFixture<FotosComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FotosComponent]
    });
    fixture = TestBed.createComponent(FotosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
