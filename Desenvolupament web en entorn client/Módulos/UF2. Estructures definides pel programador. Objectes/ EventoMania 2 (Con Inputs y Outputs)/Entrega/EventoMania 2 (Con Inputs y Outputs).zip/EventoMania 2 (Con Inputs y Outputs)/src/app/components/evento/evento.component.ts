import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Evento } from 'src/app/models/evento.model';

@Component({
  selector: 'app-evento',
  templateUrl: './evento.component.html',
  styleUrls: ['./evento.component.css']
})
export class EventoComponent {

  @Input() evento : Evento;
  @Output() guardarCambios = new EventEmitter<Evento>();

  editando: boolean = false;

  // Editar si no se está editando y guardar los cambios si se está editando
  cambiarEdicion() {
    if (this.editando) {
      this.guardarCambios.emit(this.evento);
    }

    this.editando = !this.editando;
  }

  comprobarFecha(fecha: Date) {
    this.evento.fecha = new Date(fecha);
  }

}