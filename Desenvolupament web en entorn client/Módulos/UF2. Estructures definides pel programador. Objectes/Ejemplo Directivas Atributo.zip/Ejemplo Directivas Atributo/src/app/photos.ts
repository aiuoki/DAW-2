export class Photo {
  private _id: number;
  private _img: string;
  private _desciption: string;
  private _locked: boolean;

  constructor(id: number) {
    this._id = id;
    this._locked = true;
    this._img = "https://picsum.photos/200/200";
    this._desciption = "";
  }

  get id() {
    return this._id;
  }

  get image() {
    return this._locked ? "/assets/bloquear.png" : "https://picsum.photos/200/200";
  }

  get isLocked() {
    return this._locked
  }

  chageLock() {
    this._locked = !this._locked;
  }

}