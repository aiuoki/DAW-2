import {Component} from '@angular/core';
import { Photo } from './photos';


@Component({
  selector: 'app-root',
  templateUrl:'./app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

photos: Photo[] = [new Photo(1), new Photo(2), new Photo(3), new Photo(4)];
photosSelected: Photo[] = [];

getCandaoImagen(foto: Photo): string {
  return foto.isLocked ? "assets/bloquear.png" : "assets/candado.png";
}

isPhotoSelected(photo: Photo): boolean {
  return this.photosSelected.includes(photo);
}

changeSelection(photo: Photo): void {
  if (this.isPhotoSelected(photo)) {
    this.photosSelected = this.photosSelected.filter(value => photo.id != value.id);
  } else {
    this.photosSelected.push(photo);
  }
}

 
}



