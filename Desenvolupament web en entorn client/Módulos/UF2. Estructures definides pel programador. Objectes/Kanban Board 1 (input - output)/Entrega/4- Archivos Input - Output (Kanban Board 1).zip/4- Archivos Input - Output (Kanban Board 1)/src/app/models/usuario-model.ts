export interface Usuario {
  img: string;
  alt: string;
}
